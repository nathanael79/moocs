@extends('layouts.login')

{{--
@if(!empty(Session::get('error_login')) && Session::get('error_login') == 1)
    <script>
        function errorLogin()
        {
            Swal.fire("Sesi anda telah berakhir, silahkan login kembali menggunakan akun yang telah terdaftar");

        }

        $(document).ready(function () {
            errorLogin();
        });
    </script>
@endif
--}}
