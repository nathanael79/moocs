<?php /* /opt/lampp/htdocs/moocs/resources/views/backend/mail/register.blade.php */ ?>
<?php $__env->startSection('link_container'); ?>
    <td> <div class="container">
            <center><p>Klik pada link berikut :</p></center>
            <hr>
            <center><p><a href="<?php echo e(url('/regis_confirm/'.$email.'/'.$token)); ?>">Link Konfirmasi</a></p></center>
            <hr>
            <center><p>Telah Disampaikan! <br> Terimakasih telah menghubungi kami!</p></center>
        </div>
    </td>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mail.mail_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>