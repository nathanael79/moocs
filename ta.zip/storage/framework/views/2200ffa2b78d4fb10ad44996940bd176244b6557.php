<?php /* /opt/lampp/htdocs/moocs/resources/views/frontend_register.blade.php */ ?>
<?php echo $__env->make('toast::messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('contain_section'); ?>
<!-- Start Page Title Area -->
<div class="page-title">
    <div class="d-table">
        <div class="d-table-cell">
            <div class="container">
                <h3>Register</h3>
            </div>
        </div>
    </div>
</div>
<!-- End Page Title Area -->

<!-- Start Register Area -->
<section class="register-area ptb-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="register-content">
                    <div class="heading">Register</div>
                    <form action="<?php echo e(url('/register')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">

                            <div class="col-lg-12 col-md-12">
                                <div class="form-group">
                                    <input type="email" name="email" class="form-control" placeholder="Email Address">
                                </div>
                            </div>

                            <div class="col-lg-12 col-md-12">
                                <div class="form-group">
                                    <input type="password" name="password" class="form-control" placeholder="Password">
                                </div>
                            </div>

                            <div class="col-lg-12 col-md-12">
                                <button class="btn btn-primary" type="submit">Sign Up</button>
                            </div>
                        </div>
                    </form>
                    <h4>Are you a member? <a href="<?php echo e(url('/login')); ?>">Login Now!</a></h4>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Register Area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front_end.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>