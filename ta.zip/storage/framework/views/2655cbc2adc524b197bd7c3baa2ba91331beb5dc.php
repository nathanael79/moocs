<?php /* /opt/lampp/htdocs/moocs/resources/views/auth/login.blade.php */ ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>