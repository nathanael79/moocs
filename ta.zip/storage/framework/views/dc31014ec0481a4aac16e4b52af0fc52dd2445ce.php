<?php /* /opt/lampp/htdocs/moocs/resources/views/auth/register_student.blade.php */ ?>
<?php $__env->startSection('title','MOOC PENS'); ?>


<?php echo $__env->make('layouts.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
