<?php /* /opt/lampp/htdocs/moocs/resources/views/all-courses.blade.php */ ?>
<?php $__env->startSection('contain_section'); ?>
<!-- Start Page Title Area -->
<div class="page-title">
    <div class="d-table">
        <div class="d-table-cell">
            <div class="container">
                <h3>All Courses</h3>
            </div>
        </div>
    </div>
</div>
<!-- End Page Title Area -->

<!-- Start Courses Area -->
<section class="courses-area ptb-100">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <div class="courses-item">
                    <div class="courses-img">
                        <img src="<?php echo asset('images/courses/').'/'.$item->pictures; ?>" alt="course">
                    </div>

                    <div class="courses-content">
                        <h3><a href="#"><?php echo e($item->course_name); ?></a></h3>
                        <ul>
                            <li><i class="icofont-star"></i></li>
                            <li><i class="icofont-star"></i></li>
                            <li><i class="icofont-star"></i></li>
                            <li><i class="icofont-star"></i></li>
                            <li><i class="icofont-star"></i></li>
                            <li><span>(15 reviews)</span></li>
                        </ul>

                        <p><?php echo e($item->keterangan); ?></p>
                    </div>

                    <div class="courses-content-bottom">
                        <h4 class="price"><span>$140</span> $120</h4>
                        <h4><a href="<?php echo e(url('/single-course').'/'.$item->id); ?>" class="btn btn-primary">Read More</a></h4>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="col-lg-12 col-md-12">
                <div class="pagination-area">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center">
                            <?php echo e($course->links()); ?>

                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>

</section>
<!-- End Courses Area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front_end.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>