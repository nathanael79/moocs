<?php /* /opt/lampp/htdocs/moocs/resources/views/index.blade.php */ ?>
<?php echo $__env->make('toast::messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('layouts.front_end.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>