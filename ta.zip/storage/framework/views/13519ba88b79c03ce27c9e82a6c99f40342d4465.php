<?php /* /opt/lampp/htdocs/moocs/resources/views/auth/register_student.blade.php */ ?>

<?php echo $__env->make('frontend_register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>