<?php /* /opt/lampp/htdocs/moocs/resources/views/layouts/login.blade.php */ ?>
<?php echo $__env->make('toast::messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('contain_section'); ?>
<!-- Start Page Title Area -->
<div class="page-title">
    <div class="d-table">
        <div class="d-table-cell">
            <div class="container">
                <h3>Login</h3>
            </div>
        </div>
    </div>
</div>
<!-- End Page Title Area -->

<!-- Start Login Area -->
<section class="login-area ptb-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <form id="login-form" action="<?php echo e(url('/login')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="heading">Sign in here</div>
                    <div class="left">
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="user_email" class="form-control" placeholder="Your Email">
                        </div>

                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="user_password" class="form-control" placeholder="Your Password">
                        </div>

                        <input type="submit" value="submit" class="btn btn-primary"/>
                    </div>

                    <div class="right">
                        <div class="connect">Register here</div>
                        <a href="<?php echo e(url('/register')); ?>" class="facebook">As Student</a>
                        <a href="<?php echo e(url('/lecturer/register')); ?>" class="twitter">As Lecturer</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<!-- End Login Area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front_end.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>