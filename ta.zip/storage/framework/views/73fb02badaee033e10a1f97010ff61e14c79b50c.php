<?php /* /opt/lampp/htdocs/moocs/resources/views/layouts/front_end/single-courses.blade.php */ ?>
<!doctype html>
<html lang="zxx">

<!-- Mirrored from envytheme.com/tf-demo/edufield/single-courses.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 21 May 2019 18:45:37 GMT -->
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('../../edufield/assets/css/bootstrap.min.css')); ?>">
    <!-- IcoFont Min CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('../../edufield/assets/css/icofont.min.css')); ?>">
    <!-- Classy Nav CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('../../edufield/assets/css/classy-nav.min.css')); ?>">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('../../edufield/assets/css/animate.css')); ?>">
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('../../edufield/assets/css/owl.carousel.css')); ?>">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('../../edufield/assets/css/magnific-popup.css')); ?>">
    <!-- Owl Theme Default CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('../../edufield/assets/css/owl.theme.default.min.css')); ?>">
    <!-- Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('../../edufield/assets/css/style.css')); ?>">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('../../edufield/assets/css/responsive.css')); ?>">

    <title>EduField - Education & Online Courses HTML Template</title>

    <link rel="icon" type="image/png" href="<?php echo e(asset('../../edufield/')); ?>assets/img/favicon.png">
</head>
<body>
<!-- Start Preloader Area -->
<div class="preloader-area">
    <div class="loader">
        <div class="dots">
            <i class="dots-item dots-item-move-down"></i>
            <i class="dots-item dots-item-move-left"></i>
            <i class="dots-item dots-item-move-left"></i>
            <i class="dots-item dots-item-move-left"></i>
            <i class="dots-item dots-item-move-left"></i>
            <i class="dots-item dots-item-move-down"></i>
            <i class="dots-item dots-item-move-right"></i>
            <i class="dots-item dots-item-move-right"></i>
            <i class="dots-item dots-item-move-down"></i>
            <i class="dots-item dots-item-move-up"></i>
            <i class="dots-item dots-item-move-down"></i>
            <i class="dots-item dots-item-move-up"></i>

            <i class="dots-item"></i>

            <i class="dots-item dots-item-move-down"></i>
            <i class="dots-item dots-item-move-up"></i>
            <i class="dots-item dots-item-move-down"></i>
            <i class="dots-item dots-item-move-up"></i>
            <i class="dots-item dots-item-move-left"></i>
            <i class="dots-item dots-item-move-left"></i>
            <i class="dots-item dots-item-move-up"></i>
            <i class="dots-item dots-item-move-right"></i>
            <i class="dots-item dots-item-move-right"></i>
            <i class="dots-item dots-item-move-right"></i>
            <i class="dots-item dots-item-move-right"></i>
            <i class="dots-item dots-item-move-up"></i>
        </div>
    </div>
</div>
<!-- End Preloader Area -->

<!-- Start Main Menu Area -->
<div class="main-header-area navbar-area header-sticky">
    <div class="container">
        <div class="classy-nav-container breakpoint-off">
            <!-- Classy Menu -->
            <nav class="classy-navbar justify-content-between" id="EduStudyNav">

                <!-- Logo -->
                <a class="nav-brand" href="index-default.html"><img src="assets/img/logo.png" alt="logo"></a>

                <!-- Navbar Toggler -->
                <div class="classy-navbar-toggler">
                    <span class="navbarToggler"><span></span><span></span><span></span></span>
                </div>

                <!-- Menu -->
                <div class="classy-menu">

                    <!-- close btn -->
                    <div class="classycloseIcon">
                        <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                    </div>

                    <!-- Nav Start -->
                    <div class="classynav">
                        <ul>
                            <li><a href="#">Home</a>
                                <ul class="dropdown">
                                    <li><a href="index-default.html">Home Demo One</a></li>
                                    <li><a href="index-two.html">Home Demo Two</a></li>
                                    <li><a href="index-three.html">Home Demo Three</a></li>
                                    <li><a href="index-four.html">Home Demo Four</a></li>
                                </ul>
                            </li>

                            <li><a href="#">About Us</a>
                                <ul class="dropdown">
                                    <li><a href="about.html">About Us</a></li>
                                    <li><a href="admission.html">Admission</a></li>
                                    <li><a href="teacher-style-one.html">Teacher Style One</a></li>
                                    <li><a href="teacher-style-two.html">Teacher Style Two</a></li>
                                    <li><a href="single-teacher.html">Teacher Details</a></li>
                                </ul>
                            </li>

                            <li><a href="#" class="active">Courses</a>
                                <ul class="dropdown">
                                    <li><a href="courses-style-one.html">Courses Style One</a></li>
                                    <li><a href="courses-style-two.html">Courses Style Two</a></li>
                                    <li class="active"><a href="single-courses.html">Courses Details</a></li>
                                </ul>
                            </li>

                            <li><a href="#">Events</a>
                                <ul class="dropdown">
                                    <li><a href="event-style-one.html">Events Style One</a></li>
                                    <li><a href="event-style-two.html">Events Style Two</a></li>
                                    <li><a href="single-events.html">Events Details</a></li>
                                </ul>
                            </li>

                            <li><a href="#">Pages</a>
                                <ul class="dropdown">
                                    <li><a href="about.html">About Us</a></li>
                                    <li><a href="#">Blog</a>
                                        <ul class="dropdown">
                                            <li><a href="blog-style-one.html">Blog Style One</a></li>
                                            <li><a href="blog-style-two.html">Blog Style Two</a></li>
                                            <li><a href="blog-style-three.html">Blog Style Three</a></li>
                                            <li><a href="single-blog.html">Blog Details</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Shop</a>
                                        <ul class="dropdown">
                                            <li><a href="shop-style-one.html">Shop Style One</a></li>
                                            <li><a href="shop-style-two.html">Shop Style Two</a></li>
                                            <li><a href="single-shop.html">Shop Details</a></li>
                                            <li><a href="cart.html">Cart</a></li>
                                            <li><a href="checkout.html">Checkout</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Courses</a>
                                        <ul class="dropdown">
                                            <li><a href="courses-style-one.html">Courses Style One</a></li>
                                            <li><a href="courses-style-two.html">Courses Style Two</a></li>
                                            <li><a href="single-courses.html">Courses Details</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Teacher</a>
                                        <ul class="dropdown">
                                            <li><a href="teacher-style-one.html">Teacher Style One</a></li>
                                            <li><a href="teacher-style-two.html">Teacher Style Two</a></li>
                                            <li><a href="single-teacher.html">Teacher Details</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Events</a>
                                        <ul class="dropdown">
                                            <li><a href="event-style-one.html">Events Style One</a></li>
                                            <li><a href="event-style-two.html">Events Style Two</a></li>
                                            <li><a href="single-events.html">Events Details</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Contact</a>
                                        <ul class="dropdown">
                                            <li><a href="contact-style-one.html">Contact Style One</a></li>
                                            <li><a href="contact-style-two.html">Contact Style Two</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="admission.html">Admission</a></li>
                                    <li><a href="error.html">404 Error</a></li>
                                    <li><a href="faq.html">FAQ</a></li>
                                    <li><a href="login.html">Login</a></li>
                                    <li><a href="register.html">Register</a></li>
                                </ul>
                            </li>

                            <li><a href="#">Blog</a>
                                <ul class="dropdown">
                                    <li><a href="blog-style-one.html">Blog Style One</a></li>
                                    <li><a href="blog-style-two.html">Blog Style Two</a></li>
                                    <li><a href="blog-style-three.html">Blog Style Three</a></li>
                                    <li><a href="single-blog.html">Blog Details</a></li>
                                </ul>
                            </li>

                            <li><a href="#">Shop</a>
                                <ul class="dropdown">
                                    <li><a href="shop-style-one.html">Shop Style One</a></li>
                                    <li><a href="shop-style-two.html">Shop Style Two</a></li>
                                    <li><a href="single-shop.html">Shop Details</a></li>
                                    <li><a href="cart.html">Cart</a></li>
                                    <li><a href="checkout.html">Checkout</a></li>
                                </ul>
                            </li>

                            <li><a href="#">Contact</a>
                                <ul class="dropdown">
                                    <li><a href="contact-style-one.html">Contact Style One</a></li>
                                    <li><a href="contact-style-two.html">Contact Style Two</a></li>
                                </ul>
                            </li>

                            <li><a href="#search" class="search-btn"><i class="icofont-search-2"></i></a></li>
                        </ul>
                    </div>
                    <!-- Nav End -->
                </div>
            </nav>
        </div>
    </div>
</div>
<!-- End Main Menu Area -->

<!-- Start Search Popup Area -->
<div id="search-area">
    <button type="button" class="close">×</button>
    <form>
        <input type="search" value="" placeholder="Search Kewword(s)">
        <button type="submit" class="btn btn-primary">Search</button>
    </form>
</div>
<!-- End Search Popup Area -->

<!-- Start Page Title Area -->
<div class="page-title">
    <div class="d-table">
        <div class="d-table-cell">
            <div class="container">
                <h3>Course Details</h3>
            </div>
        </div>
    </div>
</div>
<!-- End Page Title Area -->

<!-- Start Course Details Area -->
<section class="course-details-area ptb-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <div class="courses-details">
                    <div class="courses-details-meta">
                        <ul>
                            <li>
                                <div class="teacher-img">
                                    <img src="assets/img/teacher-one.jpg" alt="teacher">
                                </div>

                                Teacher: Jasika Pearl
                            </li>

                            <li>
                                Category: Design
                            </li>
                        </ul>

                        <div class="apply-btn">
                            <a href="#" class="btn btn-primary">Appy Now</a>
                        </div>
                    </div>

                    <div class="courses-details-img">
                        <img src="assets/img/courses-details.jpg" alt="courses-details">
                    </div>

                    <h3>Python for Machine Learning</h3>

                    <p>Learn how to use NumPy, Pandas, Seaborn, Matplotlib, Plotly, Scikit-Learn, Machine Learning, Tensorflow, and more!</p>

                    <div class="course-details-tabs">
                        <ul id="tabs">
                            <li class="active" id="tab_1">Description</li>
                            <li class="inactive" id="tab_2">Curriculum</li>
                            <li class="inactive" id="tab_3">Instructors</li>
                            <li class="inactive" id="tab_4">Review</li>
                        </ul>

                        <div class="content show" id="tab_1_content">
                            <h4 class="title">Course Details</h4>

                            <p>Donec lorem leo, gravida ut cursus et, ultrices non tortor. Duis vel venenatis ligula. Etiam hendrerit at urna ac tempus. Integer sagittis luctus tellus, eu molestie magna volutpat quis. Praesent ullamcorper faucibus quam. Nam sed facilisis neque. Etiam dictum dolor et volutpat malesuada. Aliquam molestie felis in justo feugiat semper. In magna arcu, luctus a nisl et, mollis ultricies sem. Etiam cursus mi eget tellus ultrices fermentum. Vestibulum tempor erat ac eros egestas rutrum.</p>

                            <p class="mb-0">Aliquam pulvinar blandit eros, vel tempor tellus eleifend eget. Vestibulum ultricies egestas ante, eu consectetur leo pretium vel. Aliquam mollis dolor libero, ac sagittis velit dignissim at. Nulla a tellus eu enim porta posuere. Sed posuere at lectus ac fringilla.</p>

                            <div class="requirements-list">
                                <h4 class="title">Requirements</h4>

                                <ul>
                                    <li><i class="icofont-double-right"></i> Use Python for Data Science and Machine Learning</li>
                                    <li><i class="icofont-double-right"></i> Use Spark for Big Data Analysis</li>
                                    <li><i class="icofont-double-right"></i> Implement Machine Learning Algorithms</li>
                                    <li><i class="icofont-double-right"></i> Learn to use NumPy for Numerical Data</li>
                                    <li><i class="icofont-double-right"></i> Learn to use Pandas for Data Analysis</li>
                                    <li><i class="icofont-double-right"></i> Learn to use Matplotlib for Python Plotting</li>
                                </ul>
                            </div>

                            <div class="certification">
                                <h4 class="title">Certification</h4>

                                <p class="mb-0">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
                            </div>
                        </div>

                        <div class="content" id="tab_2_content">
                            <div class="accordion" id="accordionEx" role="tablist" aria-multiselectable="true">
                                <div class="card">
                                    <div class="card-header" role="tab" id="headingOne">
                                        <a data-toggle="collapse" data-parent="#accordionEx" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                            <h5 class="mb-0">
                                                1. Welcome to the Courses <span><i class="icofont-rounded-down"></i></span>
                                            </h5>
                                        </a>
                                    </div>

                                    <div id="collapseOne" class="collapse show" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordionEx">
                                        <div class="card-body">
                                            <ul>
                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>

                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>

                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>

                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>

                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>

                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <div class="card">
                                    <div class="card-header" role="tab" id="headingTwo">
                                        <a class="collapsed" data-toggle="collapse" data-parent="#accordionEx" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                            <h5 class="mb-0">
                                                2. What is Python <span><i class="icofont-rounded-down"></i></span>
                                            </h5>
                                        </a>
                                    </div>

                                    <div id="collapseTwo" class="collapse" role="tabpanel" aria-labelledby="headingTwo" data-parent="#accordionEx">
                                        <div class="card-body">
                                            <ul>
                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>

                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>

                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>

                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>

                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>

                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <div class="card mb-0">
                                    <div class="card-header" role="tab" id="headingThree">
                                        <a class="collapsed" data-toggle="collapse" data-parent="#accordionEx" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                            <h5 class="mb-0">
                                                3. Welcome to the Courses <span><i class="icofont-rounded-down"></i></span>
                                            </h5>
                                        </a>
                                    </div>

                                    <div id="collapseThree" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                                        <div class="card-body">
                                            <ul>
                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>

                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>

                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>

                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>

                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>

                                                <li>
                                                    <i class="icofont-ui-play"></i> Lecture 1.1

                                                    <span><a href="#">What is Python?</a></span>

                                                    <span class="duration"><i class="icofont-clock-time"></i> 50 min</span>

                                                    <a href="#" class="preview">Preview</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="content" id="tab_3_content">
                            <div class="course-author">
                                <div class="img">
                                    <img src="assets/img/teacher-one.jpg" alt="teacher">
                                </div>

                                <div class="author-content">
                                    <h4>Jasika Perl</h4>
                                    <span>Professor</span>
                                    <ul>
                                        <li><a href="#"><i class="icofont-facebook"></i></a></li>
                                        <li><a href="#"><i class="icofont-instagram"></i></a></li>
                                        <li><a href="#"><i class="icofont-twitter"></i></a></li>
                                        <li><a href="#"><i class="icofont-linkedin"></i></a></li>
                                    </ul>
                                    <p>Aliquam pulvinar blandit eros, vel tempor tellus eleifend eget. Vestibulum ultricies egestas ante, eu consectetur leo pretium vel. Aliquam mollis dolor libero, ac sagittis velit dignissim at. Nulla a tellus eu enim porta posuere. Sed posuere at lectus ac fringilla.</p>
                                </div>
                            </div>
                        </div>

                        <div class="content" id="tab_4_content">
                            <div class="courses-review">
                                <div class="single-review">
                                    <div class="img">
                                        <img src="assets/img/teacher-one.jpg" alt="client">
                                    </div>

                                    <div class="client-content">
                                        <h4>Luyes Jagu</h4>
                                        <ul>
                                            <li><i class="icofont-star"></i></li>
                                            <li><i class="icofont-star"></i></li>
                                            <li><i class="icofont-star"></i></li>
                                            <li><i class="icofont-star"></i></li>
                                            <li><i class="icofont-star"></i></li>
                                        </ul>
                                        <p>Smply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Smply dummy text of the printing and typesetting industry.</p>
                                    </div>
                                </div>

                                <div class="single-review">
                                    <div class="img">
                                        <img src="assets/img/teacher-one.jpg" alt="client">
                                    </div>

                                    <div class="client-content">
                                        <h4>Luyes Jagu</h4>
                                        <ul>
                                            <li><i class="icofont-star"></i></li>
                                            <li><i class="icofont-star"></i></li>
                                            <li><i class="icofont-star"></i></li>
                                            <li><i class="icofont-star"></i></li>
                                            <li><i class="icofont-star"></i></li>
                                        </ul>
                                        <p>Smply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Smply dummy text of the printing and typesetting industry.</p>
                                    </div>
                                </div>

                                <div class="single-review">
                                    <div class="img">
                                        <img src="assets/img/teacher-one.jpg" alt="client">
                                    </div>

                                    <div class="client-content">
                                        <h4>Luyes Jagu</h4>
                                        <ul>
                                            <li><i class="icofont-star"></i></li>
                                            <li><i class="icofont-star"></i></li>
                                            <li><i class="icofont-star"></i></li>
                                            <li><i class="icofont-star"></i></li>
                                            <li><i class="icofont-star"></i></li>
                                        </ul>
                                        <p>Smply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Smply dummy text of the printing and typesetting industry.</p>
                                    </div>
                                </div>

                                <div class="single-review mb-0">
                                    <div class="img">
                                        <img src="assets/img/teacher-one.jpg" alt="client">
                                    </div>

                                    <div class="client-content">
                                        <h4>Luyes Jagu</h4>
                                        <ul>
                                            <li><i class="icofont-star"></i></li>
                                            <li><i class="icofont-star"></i></li>
                                            <li><i class="icofont-star"></i></li>
                                            <li><i class="icofont-star"></i></li>
                                            <li><i class="icofont-star"></i></li>
                                        </ul>
                                        <p>Smply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Smply dummy text of the printing and typesetting industry.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-12">
                <div class="side-bar mb-0">
                    <div class="single-widget features-box">
                        <h3 class="title">Course Features</h3>

                        <ul>
                            <li><i class="icofont-file-fill"></i> Lectures <span>9</span></li>

                            <li><i class="icofont-clock-time"></i> Duration <span>1.5 hours</span></li>

                            <li><i class="icofont-caret-up"></i> Skill level <span>All level</span></li>

                            <li><i class="icofont-read-book"></i> Language <span>English</span></li>

                            <li><i class="icofont-users-social"></i> Students <span>560</span></li>

                            <li><i class="icofont-certificate-alt-1"></i> Certificate <span>Yes</span></li>

                            <li><i class="icofont-checked"></i> Assessments <span>Yes</span></li>

                            <li><i class="icofont-price"></i> Price  <span>$110.99</span></li>
                        </ul>
                    </div>

                    <div class="single-widget share-boxes">
                        <h3 class="title">Share Courses</h3>

                        <ul>
                            <li><a href="#"><i class="icofont-facebook"></i></a></li>
                            <li><a href="#"><i class="icofont-twitter"></i></a></li>
                            <li><a href="#"><i class="icofont-instagram"></i></a></li>
                            <li><a href="#"><i class="icofont-linkedin"></i></a></li>
                        </ul>
                    </div>

                    <div class="single-widget latest-courses">
                        <h3 class="title">All Courses</h3>

                        <div class="single-latest-courses">
                            <div class="img">
                                <a href="#"><img src="assets/img/course-one.jpg" alt="course"></a>
                            </div>

                            <div class="content">
                                <h4><a href="#">Better tools to support dyslexic students</a></h4>

                                <p><span>$199.99</span> $110.99</p>
                            </div>
                        </div>

                        <div class="single-latest-courses">
                            <div class="img">
                                <a href="#"><img src="assets/img/course-two.jpg" alt="course"></a>
                            </div>

                            <div class="content">
                                <h4><a href="#">Better tools to support dyslexic students</a></h4>

                                <p><span>$199.99</span> $110.99</p>
                            </div>
                        </div>

                        <div class="single-latest-courses mb-0">
                            <div class="img">
                                <a href="#"><img src="assets/img/course-three.jpg" alt="course"></a>
                            </div>

                            <div class="content">
                                <h4><a href="#">Better tools to support dyslexic students</a></h4>

                                <p><span>$199.99</span> $110.99</p>
                            </div>
                        </div>
                    </div>

                    <div class="single-widget latest-courses mb-0">
                        <h3 class="title">Latest Courses</h3>

                        <div class="single-latest-courses">
                            <div class="img">
                                <a href="#"><img src="assets/img/course-one.jpg" alt="course"></a>
                            </div>

                            <div class="content">
                                <h4><a href="#">Better tools to support dyslexic students</a></h4>

                                <p><span>$199.99</span> $110.99</p>
                            </div>
                        </div>

                        <div class="single-latest-courses">
                            <div class="img">
                                <a href="#"><img src="assets/img/course-two.jpg" alt="course"></a>
                            </div>

                            <div class="content">
                                <h4><a href="#">Better tools to support dyslexic students</a></h4>

                                <p><span>$199.99</span> $110.99</p>
                            </div>
                        </div>

                        <div class="single-latest-courses mb-0">
                            <div class="img">
                                <a href="#"><img src="assets/img/course-three.jpg" alt="course"></a>
                            </div>

                            <div class="content">
                                <h4><a href="#">Better tools to support dyslexic students</a></h4>

                                <p><span>$199.99</span> $110.99</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="similar-courses">
        <div class="container">
            <h2>Similar Courses</h2>

            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="single-courses-item">
                        <div class="courses-img">
                            <img src="assets/img/course-one.jpg" alt="course">
                        </div>

                        <div class="courses-content">
                            <h3><a href="#">Machine Learning</a></h3>
                            <ul>
                                <li><i class="icofont-star"></i></li>
                                <li><i class="icofont-star"></i></li>
                                <li><i class="icofont-star"></i></li>
                                <li><i class="icofont-star"></i></li>
                                <li><i class="icofont-star"></i></li>
                            </ul>
                        </div>

                        <div class="courses-content-bottom">
                            <h4><i class="icofont-ui-user"></i> 120 Students</h4>
                            <h4 class="price">$120</h4>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="single-courses-item">
                        <div class="courses-img">
                            <img src="assets/img/course-two.jpg" alt="course">
                        </div>

                        <div class="courses-content">
                            <h3><a href="#">Learning Analytics Course</a></h3>
                            <ul>
                                <li><i class="icofont-star"></i></li>
                                <li><i class="icofont-star"></i></li>
                                <li><i class="icofont-star"></i></li>
                                <li><i class="icofont-star"></i></li>
                                <li><i class="icofont-star"></i></li>
                            </ul>
                        </div>

                        <div class="courses-content-bottom">
                            <h4><i class="icofont-ui-user"></i> 120 Students</h4>
                            <h4 class="price"><span>$140</span> $120</h4>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 offset-md-3 offset-lg-0">
                    <div class="single-courses-item">
                        <div class="courses-img">
                            <img src="assets/img/course-three.jpg" alt="course">
                        </div>

                        <div class="courses-content">
                            <h3><a href="#">Consulting Workshop</a></h3>
                            <ul>
                                <li><i class="icofont-star"></i></li>
                                <li><i class="icofont-star"></i></li>
                                <li><i class="icofont-star"></i></li>
                                <li><i class="icofont-star"></i></li>
                                <li><i class="icofont-star"></i></li>
                            </ul>
                        </div>

                        <div class="courses-content-bottom">
                            <h4><i class="icofont-ui-user"></i> 120 Students</h4>
                            <h4 class="price">$120</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Course Details Area -->

<!-- Start Footer Area -->
<footer class="footer-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="single-footer">
                    <h3>About EduField</h3>

                    <ul class="footer-contact-info">
                        <li>2750 Quadra Street , Park Area, Victoria, Canada.</li>
                        <li><a href="#">+4 (05) 345 6789</a></li>
                        <li><a href="#">+4 (15) 345 6789</a></li>
                        <li><a href="#">contact@EduField.com</a></li>
                    </ul>

                    <ul class="social">
                        <li><a href="#"><i class="icofont-facebook"></i></a></li>
                        <li><a href="#"><i class="icofont-twitter"></i></a></li>
                        <li><a href="#"><i class="icofont-linkedin"></i></a></li>
                        <li><a href="#"><i class="icofont-google-plus"></i></a></li>
                        <li><a href="#"><i class="icofont-pinterest"></i></a></li>
                    </ul>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="single-footer">
                    <h3>Courses</h3>

                    <ul class="list">
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Notice</a></li>
                        <li><a href="#">Research</a></li>
                        <li><a href="#">Scholarship</a></li>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="single-footer">
                    <h3>Research</h3>

                    <ul class="list">
                        <li><a href="#">Forums</a></li>
                        <li><a href="#">Gallery</a></li>
                        <li><a href="#">FAQs</a></li>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Login</a></li>
                        <li><a href="#">Documenation</a></li>
                    </ul>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="single-footer">
                    <h3>Support</h3>

                    <ul class="list">
                        <li><a href="#">Language Packs</a></li>
                        <li><a href="#">Relase Status</a></li>
                        <li><a href="#">Events</a></li>
                        <li><a href="#">Become A Teacher</a></li>
                        <li><a href="#">Courses</a></li>
                        <li><a href="#">LearnPress</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="copyright-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-7">
                    <p>Copyright <i class="icofont-copyright"></i> 2018 EduField Template by EnvyTheme. All rights reserved</p>
                </div>

                <div class="col-lg-5 col-md-5">
                    <ul>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Terms & Conditions</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- End Footer Area -->

<!-- Back to top -->
<a class="scrolltop" href="#top"><i class="icofont-hand-drawn-up"></i></a>
<!-- End Back to top -->

<!-- jQuery Min JS -->
<script src="<?php echo e(asset('.././edufield/assets/js/jquery.min.js')); ?>"></script>
<!-- Prpper JS -->
<script src="<?php echo e(asset('.././edufield/assets/js/popper.min.js')); ?>"></script>
<!-- Bootstrap Min JS -->
<script src="<?php echo e(asset('.././edufield/assets/js/bootstrap.min.js')); ?>"></script>
<!-- Classy Nav Min Js -->
<script src="<?php echo e(asset('.././edufield/assets/js/classy-nav.min.js')); ?>"></script>
<!-- Owl Carousel Min Js -->
<script src="<?php echo e(asset('.././edufield/')); ?>assets/js/owl.carousel.min.js"></script>
<!-- Magnific Popup JS -->
<script src="<?php echo e(asset('.././edufield/assets/js/jquery.magnific-popup.min.js')); ?>"></script>
<!-- CounterUp JS -->
<script src="<?php echo e(asset('.././edufield/assets/js/jquery.counterup.min.js')); ?>"></script>
<!-- Waypoints JS -->
<script src="<?php echo e(asset('.././edufield/assets/js/waypoints.min.js')); ?>"></script>
<!-- Form Validator Min JS -->
<script src="<?php echo e(asset('.././edufield/assets/js/form-validator.min.js')); ?>"></script>
<!-- Contact Form Min JS -->
<script src="<?php echo e(asset('.././edufield/assets/js/contact-form-script.js')); ?>"></script>
<!-- Main JS -->
<script src="<?php echo e(asset('.././edufield/assets/js/main.js')); ?>"></script>
</body>

<!-- Mirrored from envytheme.com/tf-demo/edufield/single-courses.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 21 May 2019 18:45:38 GMT -->
</html>
